# 130 pedidos prontos

Copie, troque o que está entre [colchetes] e cole na conversa com a sua IA.
Se quiser outro estilo, é só dizer no fim do pedido: "estilo lista rápida", "estilo personagem", e assim por diante.

---

## Conteúdo (30)

1. Faz um vídeo explicando o maior erro de quem está começando em [SEU NICHO], com a solução no final.
2. Faz um vídeo de lista: "3 coisas que eu faria diferente se começasse [SEU NEGÓCIO] hoje".
3. Faz um vídeo respondendo a pergunta que mais me fazem: "[PERGUNTA]".
4. Faz um vídeo mito ou verdade sobre [TEMA], com 3 mitos.
5. Faz um vídeo mostrando o antes e depois de [PROCESSO], sem prometer resultado, só o caminho.
6. Faz um vídeo contando a história de quando eu [MOMENTO DIFÍCIL] e o que aprendi com isso.
7. Faz um vídeo com 5 ferramentas que eu uso pra [TAREFA].
8. Faz uma animação explicando [CONCEITO DIFÍCIL DO SEU NICHO] como se fosse pra uma criança de 10 anos.
9. Faz um vídeo "o que ninguém te conta sobre [TEMA]".
10. Faz um vídeo comparando [OPÇÃO A] e [OPÇÃO B] e dizendo quando escolher cada uma.
11. Faz um vídeo com a minha opinião polêmica: "[OPINIÃO]". Termina perguntando se a pessoa concorda.
12. Faz um vídeo de bastidor: como é um dia de trabalho de [SUA PROFISSÃO].
13. Faz um vídeo com 3 sinais de que a pessoa precisa de [SEU SERVIÇO].
14. Faz um vídeo ensinando [DICA PRÁTICA] em 30 segundos.
15. Faz um vídeo com o passo a passo de [PROCESSO] em 4 etapas, estilo plano-sequência.
16. Faz um vídeo "pare de fazer isso" sobre [ERRO COMUM].
17. Faz um vídeo com a frase que mudou meu jeito de [TRABALHAR / VIVER]: "[FRASE]".
18. Faz um vídeo com os números do meu [MÊS / PROJETO]: [NÚMEROS REAIS].
19. Faz um vídeo explicando por que [CRENÇA COMUM] está errada.
20. Faz um vídeo respondendo um comentário: "[COMENTÁRIO]".
21. Faz um vídeo com 3 livros, cursos ou canais que mais me ajudaram em [TEMA].
22. Faz um vídeo "se eu tivesse só R$ [VALOR] pra começar [NEGÓCIO], faria assim".
23. Faz um vídeo explicando a diferença entre [TERMO A] e [TERMO B].
24. Faz um vídeo com um checklist de [TAREFA] pra salvar.
25. Faz um vídeo "o erro que me custou [CUSTO REAL]" e como evitar.
26. Faz um vídeo com uma tendência de [NICHO] pra ficar de olho este ano.
27. Faz um vídeo desmentindo a promessa "[PROMESSA FALSA COMUM NO NICHO]".
28. Faz um vídeo com perguntas e respostas rápidas sobre [TEMA], 3 perguntas.
29. Faz um vídeo motivacional pro meu público de [NICHO], com cena de cinema.
30. Faz um vídeo convidando a pessoa a me seguir, explicando o que ela vai encontrar no meu perfil.

## Anúncio (30)

31. Faz um anúncio de 20 segundos pro [PRODUTO], começando pela dor de [PÚBLICO].
32. Faz um anúncio com uma personagem que vive a dor de [DOR] e encontra [PRODUTO].
33. Faz 3 versões de gancho pro anúncio do [PRODUTO], cada uma com um ângulo diferente.
34. Faz um anúncio respondendo a objeção "[OBJEÇÃO MAIS COMUM]".
35. Faz um anúncio mostrando o que vem no [PRODUTO], item por item.
36. Faz um anúncio comparando o custo de [ALTERNATIVA CARA] com o [PRODUTO].
37. Faz um anúncio de lista: "3 motivos pra [AÇÃO] com a [MARCA]".
38. Faz um anúncio estilo frase de impacto pra [PRODUTO], com a frase "[FRASE]".
39. Faz um anúncio pra quem já visitou o site e não comprou, lembrando de [BENEFÍCIO PRINCIPAL].
40. Faz um anúncio com a garantia de [PRAZO] como argumento principal.
41. Faz um anúncio mostrando como funciona o [SERVIÇO] em 3 passos.
42. Faz um anúncio com a história de um cliente: [HISTÓRIA REAL QUE O CLIENTE AUTORIZOU].
43. Faz um anúncio com a pergunta "[PERGUNTA]" pra quem tem [DOR].
44. Faz um anúncio de oferta: [PRODUTO] por [PREÇO], só até [DATA].
45. Faz um anúncio explicando pra quem o [PRODUTO] não é.
46. Faz um anúncio estilo animação explicativa mostrando o problema que o [PRODUTO] resolve.
47. Faz um anúncio de 15 segundos só com o benefício principal e a chamada.
48. Faz um anúncio usando o print de um depoimento real: [ARQUIVO DO PRINT].
49. Faz um anúncio com "o que acontece se você não resolver [PROBLEMA]".
50. Faz um anúncio pra serviço local em [CIDADE / BAIRRO], com chamada pro WhatsApp.
51. Faz um anúncio de aplicativo / ferramenta mostrando a tela [DESCRIÇÃO DA TELA] animada.
52. Faz um anúncio com o bastidor de como o [PRODUTO] é feito.
53. Faz um anúncio de cupom: [CUPOM] com [DESCONTO], válido até [DATA].
54. Faz um anúncio pro público frio, sem citar o produto até o final.
55. Faz um anúncio com o "erro que a maioria comete com [TEMA]" e o [PRODUTO] como saída.
56. Faz um anúncio com a minha gravação [ARQUIVO], finalizado com título, legenda e destaques.
57. Faz um anúncio de recuperação de carrinho: "você esqueceu algo".
58. Faz um anúncio sazonal pro [DIA DAS MÃES / BLACK FRIDAY / NATAL] com [OFERTA].
59. Faz um anúncio comparando "fazer sozinho" e "fazer com o [PRODUTO]".
60. Faz um anúncio em formato de pergunta e resposta rápida sobre o [PRODUTO].

## Lançamento (20)

61. Faz um vídeo de aquecimento revelando o tema do meu lançamento sem dizer o produto: [TEMA].
62. Faz um convite animado pra minha aula / live gratuita: [NOME], dia [DATA] às [HORA].
63. Faz um vídeo de contagem regressiva: faltam [N] dias pra [EVENTO].
64. Faz um vídeo "o que você vai aprender na aula", com 3 tópicos: [1], [2], [3].
65. Faz um vídeo lembrando que a aula começa hoje às [HORA], com link na bio.
66. Faz um vídeo de abertura de carrinho: [PRODUTO] está aberto, com o bônus de quem entra hoje: [BÔNUS].
67. Faz um vídeo com as perguntas mais frequentes sobre o [PRODUTO] e as respostas.
68. Faz um vídeo de escassez real: [N] vagas / bônus até [DATA].
69. Faz um vídeo de último dia de carrinho, com o que a pessoa perde se não entrar.
70. Faz um vídeo apresentando o especialista do lançamento: [NOME], [CREDENCIAIS REAIS].
71. Faz um vídeo com a história de origem do método [NOME DO MÉTODO].
72. Faz um vídeo pra lista de espera: "quer ser avisado quando abrir? comenta [PALAVRA]".
73. Faz um vídeo com a quebra de objeção "não tenho tempo" pro [PRODUTO].
74. Faz um vídeo com a quebra de objeção "é caro" pro [PRODUTO], mostrando o valor.
75. Faz um vídeo mostrando a área de membros / entregáveis do [PRODUTO]: [LISTA].
76. Faz um vídeo de agradecimento pra quem participou da aula, com a oferta.
77. Faz um vídeo de bastidor do lançamento: a equipe preparando [O QUE].
78. Faz um vídeo com o resumo da aula em 30 segundos, pra quem perdeu.
79. Faz um vídeo de anúncio de captação pro evento [NOME], público [PÚBLICO].
80. Faz um vídeo de encerramento: carrinho fechado, próxima turma em [DATA].

## Perfil dark (30)

81. Faz um vídeo de frase de impacto sobre disciplina, cena de alguém treinando de madrugada.
82. Faz um vídeo estoico com uma frase de Marco Aurélio sobre controlar o que depende de você.
83. Faz um vídeo de motivação: "ninguém vai vir te salvar", cena de chuva no alto de um prédio.
84. Faz um vídeo de finanças: "3 erros que fazem seu salário acabar no dia 10".
85. Faz um vídeo de relacionamento: "ele não mudou, você é que finalmente viu".
86. Faz um vídeo de fé: uma palavra pra quem está cansado, cena de luz entrando por uma janela.
87. Faz um vídeo de produtividade: "você não tem falta de tempo, tem excesso de celular".
88. Faz um vídeo de autocontrole: "24 horas sem rede social", com cena de quarto escuro e celular.
89. Faz um vídeo de maternidade: "mãe, você não está fazendo errado, está cansada".
90. Faz um vídeo de pets: "seu cachorro não é teimoso", com cena de cachorro olhando pro dono.
91. Faz um vídeo de hábitos: "não é força de vontade, é ambiente".
92. Faz um vídeo de lista estoica: "3 regras de Sêneca pra dias difíceis".
93. Faz um vídeo de motivação com história: alguém que começou do zero, com virada no final.
94. Faz um vídeo de finanças: "o que acontece se você guardar R$ [VALOR] por mês", com gráfico.
95. Faz um vídeo de reflexão: "o que você vai dizer pro seu eu de 5 anos atrás?".
96. Faz um vídeo de disciplina: "5 da manhã, de novo", cena de despertador e cidade escura.
97. Faz um vídeo de autoestima: "pare de se diminuir pra caber na vida dos outros".
98. Faz um vídeo de estudos: "como estudar 1 hora por dia sem desistir".
99. Faz um vídeo de motivação com a pergunta "comenta SIM se você vai começar hoje".
100. Faz um vídeo estilo plano-sequência explicando como funciona um perfil dark.
101. Faz um vídeo de frase de impacto: "faz calado, colhe alto".
102. Faz um vídeo de fé: "se esse vídeo chegou até você, não é por acaso".
103. Faz um vídeo de finanças: "o boleto que ninguém te contou que você paga todo mês".
104. Faz um vídeo de relacionamento: "quem quer ficar dá um jeito, quem não quer dá uma desculpa".
105. Faz um vídeo de motivação pra segunda-feira, cena de estrada vazia ao amanhecer.
106. Faz um vídeo de mente: "seu cérebro foi treinado pra querer tudo agora".
107. Faz um vídeo de lista: "3 hábitos de quem acorda cedo".
108. Faz um vídeo com o ebook do perfil: "[NOME DO EBOOK]", chamada "link na bio".
109. Faz um vídeo pergunta que provoca: "você trocaria seu salário por liberdade?".
110. Faz um vídeo de encerramento de semana: "o que você fez por você essa semana?".

## Loja e negócio local (20)

111. Faz um vídeo da oferta da semana: [PRODUTO] por [PREÇO], chamada pro WhatsApp. Foto: [ARQUIVO].
112. Faz um vídeo de novidade chegando na loja: [PRODUTOS]. Fotos: [ARQUIVOS].
113. Faz um vídeo convidando pra visitar a loja em [ENDEREÇO], com horário [HORÁRIO].
114. Faz um vídeo de Dia das Mães com sugestões de presente até R$ [VALOR].
115. Faz um vídeo de Black Friday da loja: [OFERTAS], só no dia [DATA].
116. Faz um vídeo "3 jeitos de usar [PRODUTO]".
117. Faz um vídeo de queima de estoque: [PRODUTO] com [DESCONTO] até acabar.
118. Faz um vídeo apresentando a equipe da loja: [NOMES E FUNÇÕES].
119. Faz um vídeo de bastidor: como o [PRODUTO / PRATO] é feito.
120. Faz um vídeo com o depoimento real de um cliente: [TEXTO QUE O CLIENTE AUTORIZOU].
121. Faz um vídeo de entrega / delivery: "a gente entrega em [BAIRROS]".
122. Faz um vídeo de serviço: como funciona o atendimento da [CLÍNICA / OFICINA / SALÃO].
123. Faz um vídeo de agenda aberta: "horários livres essa semana, chama no WhatsApp".
124. Faz um vídeo de produto mais vendido do mês: [PRODUTO].
125. Faz um vídeo de kit / combo: [ITENS] por [PREÇO].
126. Faz um vídeo de lançamento de cardápio / coleção: [NOME].
127. Faz um vídeo de sorteio com as regras: [REGRAS].
128. Faz um vídeo de aniversário da loja: [N] anos, com a oferta comemorativa [OFERTA].
129. Faz um vídeo de "antes de comprar [PRODUTO], olha isso", com dicas reais.
130. Faz um vídeo de fim de expediente agradecendo os clientes do dia, com cena da loja fechando.
