# INSTALAR · instruções pra IA

Você é o Claude Code ou o Codex de uma pessoa que comprou o Córtex. Siga estes passos, avisando em português simples o que está fazendo em cada um. Não peça confirmação pra cada comando: peça só quando precisar de algo dela (as chaves, uma instalação que exija senha).

## 1. Descobrir o ambiente

- Sistema: macOS ou Windows.
- Qual IA você é: Claude Code ou Codex.
- Pasta de skills:
  - Claude Code: `~/.claude/skills/` (no Windows: `%USERPROFILE%\.claude\skills\`)
  - Codex: `~/.agents/skills/` (no Windows: `%USERPROFILE%\.agents\skills\`)

## 2. Requisitos

Confira e, se faltar, instale (ou mostre o comando pra pessoa rodar, quando exigir senha):
- **Node 20 ou mais novo:** `node -v`. Se faltar: Mac `brew install node`; Windows `winget install OpenJS.NodeJS.LTS`.
- **FFmpeg:** `ffmpeg -version`. Se faltar: Mac `brew install ffmpeg`; Windows `winget install Gyan.FFmpeg`. No Windows, depois de instalar, o terminal precisa ser reaberto.
- **Homebrew (só Mac, só se faltar):** mostre o comando oficial de https://brew.sh pra pessoa rodar.

## 3. Instalar o Implante

1. Copie a pasta `cortex/` deste pacote pra pasta de skills da sua IA, como `cortex`.
2. No Codex, acrescente também esta linha ao arquivo `~/.codex/AGENTS.md` (crie se não existir):
   `Quando a pessoa pedir qualquer vídeo, leia e siga ~/.agents/skills/cortex/SKILL.md.`
3. Crie o arquivo `cortex/.env` (dentro da pasta instalada) com este conteúdo:
   ```
   ELEVENLABS_API_KEY=
   GEMINI_API_KEY=
   CORTEX_VOICE_ID=
   ```
4. Copie as pastas `pedidos/` e `bonus/` pra uma pasta de trabalho da pessoa: `~/Cortex/` (no Windows, `%USERPROFILE%\Cortex\`). Crie também `~/Cortex/videos/`.

## 4. Instalar o motor de vídeo

Rode:
```
npx --yes hyperframes skills
```
Isso instala as instruções do HyperFrames (o motor que monta e renderiza os vídeos) na sua IA. Depois rode `npx --yes hyperframes doctor` e resolva o que ele apontar.

## 5. As duas chaves

Explique pra pessoa, uma de cada vez:

**ElevenLabs (a voz):**
1. Entrar em https://elevenlabs.io e criar a conta (tem plano grátis pra começar).
2. Clicar no nome dela no canto inferior esquerdo → **API Keys** → **Create API Key**, liberando "Text to Speech" e "Voices".
3. Copiar a chave e colar aqui na conversa.

**Gemini (as imagens) · opcional:**
Explique que a geração automática de imagem pela API do Google é paga (alguns centavos por imagem, cobrados pelo Google) e não tem cota grátis. Sem ela, o Córtex funciona igual: as cenas são geradas de graça no app do Gemini, ou vêm das fotos da pessoa. Pergunte se ela quer ativar agora. Se quiser:
1. Entrar em https://aistudio.google.com com a conta Google.
2. Clicar em **Get API key** → **Create API key**, e ativar o faturamento do projeto quando o Google pedir.
3. Copiar a chave e colar aqui na conversa.

Salve cada chave no `cortex/.env`. Nunca mostre a chave de volta na conversa e nunca salve em outro lugar.

## 6. Escolher a voz

Rode `node <pasta do cortex>/ferramentas/voz.mjs vozes`, sugira 2 ou 3 vozes que falem bem português e salve a escolhida em `CORTEX_VOICE_ID`.

## 7. Conferir

Rode `node <pasta do cortex>/ferramentas/verificar.mjs`. Tudo precisa aparecer com ✓ (a chave do Gemini é opcional).

## 8. Avisar que está pronto

Diga exatamente:

> Córtex instalado. Os cinco módulos estão prontos: roteiro, cena, voz, montagem e finalização.
> Os seus 130 pedidos prontos estão na pasta Cortex/pedidos. Os vídeos vão ficar em Cortex/videos.
> Qual vídeo a gente faz primeiro?
