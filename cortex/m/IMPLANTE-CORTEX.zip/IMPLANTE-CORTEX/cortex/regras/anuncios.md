# Anúncios: o que pode barrar

Quando o vídeo for anúncio (Meta, TikTok, YouTube), confira o roteiro contra esta lista e avise a pessoa de qualquer ponto. Você não é advogado nem a plataforma: o aviso é preventivo, a decisão é dela.

## Frases de risco

- **Atributo pessoal:** falar diretamente da condição de quem vê. "Você está acima do peso?", "Você está endividado?". Prefira falar do assunto: "Pra quem quer sair das dívidas".
- **Promessa de ganho:** "ganhe R$ 10 mil por mês", "renda garantida", "fique rico".
- **Antes e depois de corpo**, e promessa de resultado de saúde ("perca 10 kg em 2 semanas", "cura").
- **Urgência falsa:** "últimas vagas" quando não é verdade, contador falso.
- **Botão falso:** imagem que imita botão de play, de sistema ou notificação do celular pra induzir clique.
- **Marcas e pessoas de terceiros** sem autorização.

## Áreas sensíveis

Saúde, finanças, crédito, emprego, imóveis, política e jogos têm regras próprias em cada plataforma. Nesses casos, avise a pessoa pra conferir a política atual da plataforma antes de subir.

## Como avisar

"Atenção: a frase '[FRASE]' pode ser barrada no anúncio porque [motivo]. Sugestão: '[ALTERNATIVA]'. Quer que eu troque?"
