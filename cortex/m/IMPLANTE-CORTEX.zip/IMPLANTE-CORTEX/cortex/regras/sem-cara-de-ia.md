# Sem cara de IA

Texto e visual com cara de robô derrubam a retenção e a conversão. Estas regras valem pra roteiro, texto na tela, legenda de post e qualquer mensagem.

## Na escrita

- **Travessão está proibido.** Use vírgula, ponto ou dois pontos.
- Nada de abertura genérica: "No mundo de hoje", "Em um mercado cada vez mais...".
- Não repita a fórmula "não é X, é Y". Uma vez passa, três entrega o jogo.
- Nada de trio de adjetivos ("prático, rápido e eficiente").
- Evite: "desbloqueie", "eleve", "mergulhe", "transforme sua jornada", "descubra o poder de".
- Emoji não é marcador de seção.
- Frase que serve pra qualquer empresa não serve pra nenhuma. Use o detalhe do negócio da pessoa.
- Frase curta. Número concreto. Exemplo real.
- Escreva como a pessoa fala com o cliente dela, não como um anúncio de banco.

## No visual

- Sem degradê roxo e azul.
- Sem selo arredondado em caixa alta no topo de tudo.
- Sem tudo centralizado o tempo todo: varie a composição.
- Hierarquia por tamanho e peso de letra, não por caixinha.
- Movimento com intenção: cada animação mostra algo que a voz está dizendo.

## Nunca invente

Número de resultado, depoimento, nome de cliente, preço, data. Se não foi informado, pergunte ou deixe de fora.
