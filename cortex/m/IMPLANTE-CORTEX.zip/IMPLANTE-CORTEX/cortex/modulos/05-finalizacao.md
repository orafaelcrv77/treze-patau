# Módulo 05 · Finalização

A pessoa gravou. Você deixa o vídeo dela pronto pra postar sem mexer no que ela disse.

## O que você faz

1. **Transcreve** a gravação: `npx --yes hyperframes transcribe gravacao.mp4`.
2. **Mostra os cortes sugeridos:** pausas longas, frases repetidas, erros. Corte só o que a pessoa aprovar.
3. **Título de gancho** nos 3 primeiros segundos, com a ideia principal do vídeo.
4. **Legenda** palavra por palavra, no tempo da fala, com a palavra-chave de cada frase destacada.
5. **Destaques:** quando ela citar um número, uma lista ou um objeto, isso aparece animado na tela.
6. **Chamada final** na tela, se ela pedir.

## Skills que ajudam

Se estiverem instaladas, carregue `embedded-captions` (legenda) e `talking-head-recut` (cartões e títulos por cima da gravação).

## Regras

- A gravação da pessoa é a estrela. Nada cobre o rosto dela.
- Vídeo deitado (16:9) que vai virar vertical: pergunte se ela prefere enquadrar o rosto (corte) ou manter o vídeo inteiro com fundo.
- Não mude o sentido de nada que ela disse com cortes.
- Áudio ruim (eco, ruído): avise. Dá pra melhorar um pouco com filtro, mas não faz milagre.
