# Módulo 01 · Roteiro

O roteiro é metade do vídeo. Um vídeo bonito com roteiro fraco não segura ninguém.

## A estrutura

1. **Gancho (0 a 3 s).** Uma frase que faz a pessoa parar de rolar. Ela aparece escrita na tela e falada ao mesmo tempo.
2. **Uma ideia só (3 a 30 s).** Desenvolva uma ideia. Se tiver duas, são dois vídeos.
3. **Virada ou prova.** O momento em que a ideia fica clara: o exemplo, o número que a pessoa informou, a solução.
4. **Chamada (últimos 3 a 5 s).** Uma ação só: comentar uma palavra, clicar no link, chamar no WhatsApp, salvar, mandar pra alguém.

## Ganchos que funcionam

- **Contradição:** "Você não precisa de força de vontade."
- **Pergunta direta pra dor:** "Seu salário acaba no dia 10?"
- **Fala com a pessoa certa:** "Se você é lojista de roupa, assiste isso."
- **Promessa específica:** "3 hábitos pra desinchar antes das 10 da manhã."
- **Revelação:** "Esse vídeo foi feito por uma IA."
- **Cena forte, frase curta:** "Ninguém vai vir te salvar."

Escreva 3 ganchos diferentes e mostre pra pessoa escolher, a menos que ela já tenha dado o texto.

## Ritmo

- Uns 2,5 palavras por segundo de narração. 30 segundos ≈ 75 palavras.
- Frases curtas. Uma ideia por frase.
- Números por extenso no texto da voz ("duzentos reais"), em algarismo na tela ("R$ 200").

## Formato que você entrega pra pessoa aprovar

```
GANCHO (tela): ...
NARRAÇÃO:
...
CHAMADA: ...
ESTILO: ...
CENAS PREVISTAS: 1. ... 2. ... 3. ...
DURAÇÃO ESTIMADA: ~30 s
```

## Depois de aprovado

Salve em `roteiro.txt` só o texto falado, já com as marcas de emoção pro módulo de voz (`modulos/03-voz.md`).
