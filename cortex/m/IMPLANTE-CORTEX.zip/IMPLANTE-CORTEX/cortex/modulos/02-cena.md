# Módulo 02 · Cena

As cenas são as imagens do vídeo. Elas precisam parecer foto de câmera de verdade, não ilustração de IA.

## Quando gerar cena

- Estilos com pessoa, lugar ou produto (frase de impacto, personagem realista, oferta, história narrada).
- Estilos só de animação (plano-sequência, animação explicativa, lista rápida) normalmente não precisam de cena: tudo é desenhado no HyperFrames.

## Três caminhos pra ter as cenas

**A. Automático (chave do Google com faturamento ativo).** A geração de imagem pela API do Gemini não tem cota grátis. Se a pessoa ativou o faturamento no aistudio.google.com (custa alguns centavos por imagem), rode:

```
node ferramentas/imagem.mjs "DESCRIÇÃO" videos/<pasta>/cenas/01.jpg --formato=9:16
```

Se a ferramenta sair com código 2 (sem chave) ou 3 (recusado por limite/faturamento), vá pro caminho B sem insistir.

**B. Manual e gratuito (app do Gemini).** Escreva a descrição pronta de cada cena e peça pra pessoa:
1. abrir https://gemini.google.com, escolher criar imagem e colar a descrição;
2. baixar a imagem e salvar na pasta `videos/<pasta>/cenas/` com o nome que você indicar (01.jpg, 02.jpg...).
Espere ela avisar que salvou e confira os arquivos antes de seguir.

**C. Fotos da pessoa.** Produto, loja, equipe, o próprio rosto. Peça os arquivos e use direto, com recorte e movimento na montagem.

Lembre: plano-sequência, animação explicativa, lista rápida, convite animado, pergunta que provoca e finalização não precisam de cena. São desenhados na montagem.

## Como descrever a cena

Monte a descrição sempre com estes blocos, nesta ordem:
1. **Quem/o quê:** "Mulher de 35 anos, cabelo castanho preso, camiseta terracota"
2. **Fazendo o quê:** "dobrando roupas no balcão"
3. **Onde:** "dentro de uma loja de roupa pequena de bairro, prateleiras cheias"
4. **Luz e clima:** "luz natural da porta, fim de tarde, cores quentes"
5. **Câmera:** "lente 35mm, profundidade de campo rasa, enquadramento vertical"

## Mesma personagem em várias cenas

1. Gere primeiro um retrato de referência: frente e meio perfil, mesma roupa, fundo neutro.
2. Em todas as cenas seguintes, passe esse retrato como referência: `--ref=cenas/ref.jpg` (no caminho manual, peça pra pessoa anexar o retrato no app do Gemini junto com a descrição).
3. Repita na descrição os detalhes fixos (roupa, cabelo, idade) em todas as cenas.

## A partir de uma foto da pessoa

Se ela mandar a foto do produto, da loja ou o próprio rosto, use `--ref=` com essa foto (ou peça pra anexar no app do Gemini) e descreva a cena nova. Sempre avise que a cena vai ser uma recriação, não a foto original.

## Regras

- Texto dentro da imagem sai embaralhado. Peça sempre sem texto e escreva o texto depois, na montagem.
- Calendário, caderno, etiqueta e tela de celular: peça em branco e preencha na montagem.
- Gere uma cena, mostre, e só então gere as outras no mesmo padrão.
- Nunca gere pessoa real conhecida, marca de terceiros ou logotipo que a pessoa não autorizou.
- Movimento: as cenas ganham movimento na montagem (zoom lento, deslocamento, recorte). Se a pessoa tiver acesso a um gerador de vídeo (como o Veo, no Google Flow), ela pode transformar a cena em vídeo e mandar o arquivo. Você usa normalmente.
