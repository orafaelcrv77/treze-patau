# Módulo 03 · Voz

A narração é o que faz o vídeo parecer feito por gente.

## Gerar

```
node ferramentas/voz.mjs gerar videos/<pasta>/roteiro.txt videos/<pasta>/narracao.mp3
```

O modelo padrão é o `eleven_v3`, que entende marcas de emoção entre colchetes.

## Marcas de emoção

Use poucas, onde a emoção muda de verdade. Com marca demais, a voz fica teatral.

| Marca | Quando |
|---|---|
| `[softly]` | segredo, intimidade, abertura de mistério |
| `[excited]` | virada, revelação, chamada final |
| `[serious]` | conta, dado, alerta |
| `[warm]` | garantia, acolhimento |
| `[curious]` | pergunta |
| `[pause]` | antes de algo importante |
| `[sighs]` | dor, cansaço |
| `[laughs softly]` | ironia leve |

Reticências (...) também criam pausa natural.

## Regras

- Números e siglas por extenso: "noventa e sete reais", "dez por cento", "I A" (se a voz soletrar errado).
- Se uma palavra sair com pronúncia estranha, escreva como se fala.
- Gere uma vez e confira a duração com `ffprobe`. Se passar do limite, corte texto. Não acelere a voz mais que 5%.
- Você não ouve áudio: depois de gerar, peça pra pessoa escutar e aprovar antes de montar.

## Depois de aprovado

Transcreva com o tempo de cada palavra. É isso que sincroniza legenda e animação:

```
npx --yes hyperframes transcribe videos/<pasta>/narracao.mp3
```
