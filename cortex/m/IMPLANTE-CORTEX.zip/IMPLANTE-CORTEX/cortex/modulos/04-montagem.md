# Módulo 04 · Montagem

Aqui as peças viram vídeo. A montagem usa o HyperFrames (vídeo feito em HTML, renderizado em MP4).
Antes de montar o primeiro vídeo, carregue a skill `hyperframes` e siga o fluxo dela pra estrutura da composição.

## Preparar o projeto

```
cd videos/<pasta>
npx --yes hyperframes init projeto
```

Copie pra `projeto/assets/`: as cenas, a narração e a transcrição.

## Linguagem visual do Córtex

- Fundo escuro com textura sutil, ou a própria cena escurecida por baixo do texto.
- Tipografia: um título pesado (peso 900) e um destaque em itálico serifado pra palavra mais importante.
- Uma cor de destaque só por vídeo (ou a cor da marca da pessoa, se ela tiver).
- Legenda palavra por palavra, acendendo no tempo exato da fala (use a transcrição).
- Câmera sempre andando: zoom lento, deslocamento. Nada parado mais de 2 segundos.
- "Quando falar, desenhe": se a narração cita um número, ele conta na tela; se fala de crescimento, a linha sobe; se cita um objeto, ele aparece desenhado.
- Transições com direção: o que sai pra esquerda puxa o que entra pela direita.

Cada estilo do `estilos/catalogo.md` tem a receita da montagem.

## Áudio

- Trilha: peça pra pessoa uma música que ela tenha direito de usar, ou monte sem trilha.
- Mixe com `node ferramentas/mixar.mjs narracao.mp3 assets/mix.wav --trilha=musica.mp3`. A trilha abaixa sozinha quando a voz fala.
- Efeitos sonoros: use a skill `hyperframes-audio` ou `media-use` se estiverem disponíveis. Se não, entregue sem efeitos.

## Conferir antes do render

```
npx --yes hyperframes check projeto
npx --yes hyperframes snapshot projeto --at 1,3,8,15,25
```

Olhe os snapshots. Corrija texto cortado, texto em cima de texto e legenda fora do lugar.

## Render

```
npx --yes hyperframes render projeto --quality delivery -o ../video-final.mp4
```

Pra postar, comprima mantendo a qualidade:

```
ffmpeg -i video-final.mp4 -c:v libx264 -crf 18 -preset slow -pix_fmt yuv420p -c:a aac -b:a 192k -movflags +faststart video-pronto.mp4
```
