#!/usr/bin/env node
// Córtex · verificação do ambiente
// Uso: node verificar.mjs
// Confere se tudo que o Córtex precisa está instalado e configurado.
import { execSync } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import os from "node:os";

const here = dirname(fileURLToPath(import.meta.url));
const ok = (m) => console.log("  ✓ " + m);
const bad = (m, fix) => { console.log("  ✗ " + m + (fix ? "\n      → " + fix : "")); falhas++; };
let falhas = 0;

function cmd(c) { try { return execSync(c, { stdio: ["ignore", "pipe", "ignore"] }).toString().trim(); } catch { return null; } }

console.log("\nCÓRTEX · verificando o ambiente\n");

const nodeV = process.versions.node.split(".").map(Number);
nodeV[0] >= 20 ? ok("Node " + process.versions.node) : bad("Node " + process.versions.node + " (precisa 20 ou mais novo)", "Instale o Node LTS em https://nodejs.org");

const ff = cmd("ffmpeg -version");
ff ? ok("FFmpeg " + (ff.split("\n")[0].split(" ")[2] || "")) : bad("FFmpeg não encontrado", os.platform() === "darwin" ? "brew install ffmpeg" : "winget install Gyan.FFmpeg  (depois feche e abra o terminal)");

const hf = cmd("npx --yes hyperframes --version");
hf ? ok("HyperFrames " + hf.split("\n").pop()) : bad("HyperFrames não respondeu", "npx --yes hyperframes doctor");

// chaves
const envPath = join(here, "..", ".env");
const env = {};
if (existsSync(envPath)) for (const l of readFileSync(envPath, "utf8").split(/\r?\n/)) { const m = l.match(/^\s*([A-Z_]+)\s*=\s*(.*)\s*$/); if (m) env[m[1]] = m[2].replace(/^["']|["']$/g, ""); }
const get = (k) => process.env[k] || env[k];

get("ELEVENLABS_API_KEY") ? ok("Chave do ElevenLabs configurada") : bad("Chave do ElevenLabs ausente", "Crie em elevenlabs.io → Developers → API Keys e salve em cortex/.env como ELEVENLABS_API_KEY=...");
get("GEMINI_API_KEY") ? ok("Chave do Gemini configurada (geração automática de cenas)") : console.log("  • Sem chave do Gemini: as cenas vão pelo caminho manual ou pelas suas fotos (opcional)");

// teste rápido das chaves, sem gastar crédito
if (get("ELEVENLABS_API_KEY")) {
  try {
    const r = await fetch("https://api.elevenlabs.io/v1/user", { headers: { "xi-api-key": get("ELEVENLABS_API_KEY") } });
    r.ok ? ok("ElevenLabs respondeu") : bad("ElevenLabs recusou a chave (" + r.status + ")", "Confira se copiou a chave inteira");
  } catch { bad("Sem conexão com o ElevenLabs"); }
}
if (get("GEMINI_API_KEY")) {
  try {
    const r = await fetch("https://generativelanguage.googleapis.com/v1beta/models?key=" + get("GEMINI_API_KEY"));
    r.ok ? ok("Gemini respondeu") : bad("Gemini recusou a chave (" + r.status + ")", "Confira se copiou a chave inteira");
  } catch { bad("Sem conexão com o Gemini"); }
}

console.log(falhas ? `\n${falhas} item(ns) pra resolver.\n` : "\nTudo pronto. Pode pedir o primeiro vídeo.\n");
process.exit(falhas ? 1 : 0);
