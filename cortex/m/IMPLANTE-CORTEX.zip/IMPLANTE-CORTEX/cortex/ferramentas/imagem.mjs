#!/usr/bin/env node
// Córtex · módulo de cena (Google Gemini, geração de imagem)
// Precisa de GEMINI_API_KEY com faturamento ativo no Google AI Studio
// (a geração de imagem não tem cota grátis na API).
// Sem chave paga, use o caminho manual descrito em modulos/02-cena.md.
//
// Uso:
//   node imagem.mjs "descrição da cena" saida.jpg [--formato=9:16] [--ref=foto.jpg] [--ref=outra.jpg] [--modelo=ID]
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { join, dirname, extname } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const env = {};
const envPath = join(here, "..", ".env");
if (existsSync(envPath)) for (const l of readFileSync(envPath, "utf8").split(/\r?\n/)) { const m = l.match(/^\s*([A-Z_]+)\s*=\s*(.*)\s*$/); if (m) env[m[1]] = m[2].replace(/^["']|["']$/g, ""); }
const get = (k) => process.env[k] || env[k];
const KEY = get("GEMINI_API_KEY");
if (!KEY) { console.error("Sem GEMINI_API_KEY. Use o caminho manual (modulos/02-cena.md) ou configure uma chave com faturamento ativo."); process.exit(2); }

const args = process.argv.slice(2);
const refs = args.filter((a) => a.startsWith("--ref=")).map((a) => a.slice(6));
const opt = Object.fromEntries(args.filter((a) => a.startsWith("--") && !a.startsWith("--ref=")).map((a) => a.slice(2).split("=")));
const [descricao, saida] = args.filter((a) => !a.startsWith("--"));
if (!descricao || !saida) { console.error('Uso: node imagem.mjs "descrição" saida.jpg [--formato=9:16] [--ref=foto.jpg]'); process.exit(1); }

const formato = opt.formato || "9:16";
const texto = descricao + "\n\nFotografia fotorrealista, com cara de foto de câmera de verdade. Sem texto, sem letras, sem marca d'água.";
const mime = (f) => ({ ".png": "image/png", ".webp": "image/webp" }[extname(f).toLowerCase()] || "image/jpeg");
const refData = refs.map((f) => ({ mime: mime(f), data: readFileSync(f).toString("base64") }));

// acha a primeira imagem em qualquer formato de resposta do Google
function acharImagem(o) {
  if (!o || typeof o !== "object") return null;
  if (o.inlineData?.data) return o.inlineData.data;
  if (o.inline_data?.data) return o.inline_data.data;
  if (o.type === "image" && typeof o.data === "string" && o.data.length > 1000) return o.data;
  for (const v of Array.isArray(o) ? o : Object.values(o)) { const r = acharImagem(v); if (r) return r; }
  return null;
}

async function viaInteractions(modelo) {
  const input = refData.length ? [{ type: "text", text: texto }, ...refData.map((r) => ({ type: "image", mime_type: r.mime, data: r.data }))] : texto;
  const r = await fetch("https://generativelanguage.googleapis.com/v1beta/interactions", {
    method: "POST", headers: { "content-type": "application/json", "x-goog-api-key": KEY },
    body: JSON.stringify({ model: modelo, input, response_format: { type: "image", mime_type: "image/jpeg", aspect_ratio: formato } })
  });
  return { status: r.status, body: await r.text() };
}
async function viaGenerateContent(modelo) {
  const parts = [...refData.map((r) => ({ inlineData: { mimeType: r.mime, data: r.data } })), { text: texto }];
  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${modelo}:generateContent`, {
    method: "POST", headers: { "content-type": "application/json", "x-goog-api-key": KEY },
    body: JSON.stringify({ contents: [{ parts }], generationConfig: { responseModalities: ["IMAGE"], imageConfig: { aspectRatio: formato } } })
  });
  return { status: r.status, body: await r.text() };
}

const modelo = opt.modelo || get("CORTEX_IMAGE_MODEL") || "gemini-nano-banana-2.1";
let res = await viaInteractions(modelo);
if (res.status === 404 || res.status === 400) res = await viaGenerateContent(opt.modelo || get("CORTEX_IMAGE_MODEL") || "gemini-2.5-flash-image");

if (res.status === 429) {
  console.error("O Google recusou por limite ou falta de faturamento (429). A geração de imagem pela API exige faturamento ativo em aistudio.google.com. Enquanto isso, use o caminho manual (modulos/02-cena.md).");
  process.exit(3);
}
if (res.status >= 300) { console.error("Erro " + res.status + ": " + res.body.slice(0, 600)); process.exit(1); }
let json; try { json = JSON.parse(res.body); } catch { console.error("Resposta inesperada do Google."); process.exit(1); }
const b64 = acharImagem(json);
if (!b64) { console.error("O modelo não devolveu imagem. Reescreva a descrição (sem pessoas reais, sem marcas) e tente de novo.\n" + res.body.slice(0, 400)); process.exit(1); }
writeFileSync(saida, Buffer.from(b64, "base64"));
console.log("Cena salva em " + saida);
