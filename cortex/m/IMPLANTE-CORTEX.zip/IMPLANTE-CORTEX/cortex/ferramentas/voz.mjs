#!/usr/bin/env node
// Córtex · módulo de voz (ElevenLabs)
// Uso:
//   node voz.mjs vozes                         → lista as vozes da conta
//   node voz.mjs gerar roteiro.txt saida.mp3   → gera a narração
// Opções: --voz=ID  --modelo=eleven_v3
// Textos longos são divididos por parágrafo (o eleven_v3 aceita até 3.000 caracteres por vez)
// e as partes são juntadas no final.
import { readFileSync, writeFileSync, existsSync, mkdtempSync, rmSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";
import os from "node:os";

const here = dirname(fileURLToPath(import.meta.url));
const env = {};
const envPath = join(here, "..", ".env");
if (existsSync(envPath)) for (const l of readFileSync(envPath, "utf8").split(/\r?\n/)) { const m = l.match(/^\s*([A-Z_]+)\s*=\s*(.*)\s*$/); if (m) env[m[1]] = m[2].replace(/^["']|["']$/g, ""); }
const get = (k) => process.env[k] || env[k];
const KEY = get("ELEVENLABS_API_KEY");
if (!KEY) { console.error("Falta ELEVENLABS_API_KEY no arquivo cortex/.env"); process.exit(1); }

const args = process.argv.slice(2);
const opt = Object.fromEntries(args.filter((a) => a.startsWith("--")).map((a) => a.slice(2).split("=")));
const pos = args.filter((a) => !a.startsWith("--"));
const LIMITE = 2800;

if (pos[0] === "vozes") {
  const r = await fetch("https://api.elevenlabs.io/v1/voices", { headers: { "xi-api-key": KEY } });
  if (!r.ok) { console.error("Erro " + r.status + ": " + (await r.text())); process.exit(1); }
  const { voices } = await r.json();
  for (const v of voices) console.log(`${v.voice_id}  ${v.name}  ${v.labels ? Object.values(v.labels).join(", ") : ""}`);
  console.log("\nSalve a escolhida em cortex/.env como CORTEX_VOICE_ID=<id>");
  process.exit(0);
}

function dividir(texto) {
  const blocos = texto.split(/\n\s*\n/).map((b) => b.trim()).filter(Boolean);
  const partes = []; let atual = "";
  for (const b of blocos) {
    if (b.length > LIMITE) {
      // parágrafo gigante: quebra por frase
      for (const f of b.split(/(?<=[.!?…])\s+/)) {
        if ((atual + " " + f).length > LIMITE && atual) { partes.push(atual.trim()); atual = ""; }
        atual += " " + f;
      }
    } else if ((atual + "\n\n" + b).length > LIMITE && atual) { partes.push(atual.trim()); atual = b; }
    else atual += (atual ? "\n\n" : "") + b;
  }
  if (atual.trim()) partes.push(atual.trim());
  return partes;
}

async function tts(texto, voz, saida, anterior, seguinte) {
  const body = { text: texto, model_id: opt.modelo || "eleven_v3" };
  if (anterior) body.previous_text = anterior.slice(-300);
  if (seguinte) body.next_text = seguinte.slice(0, 300);
  const r = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voz}?output_format=mp3_44100_128`, {
    method: "POST", headers: { "xi-api-key": KEY, "content-type": "application/json", accept: "audio/mpeg" }, body: JSON.stringify(body)
  });
  if (!r.ok) { console.error("Erro " + r.status + ": " + (await r.text())); process.exit(1); }
  writeFileSync(saida, Buffer.from(await r.arrayBuffer()));
}

if (pos[0] === "gerar") {
  const [, entrada, saida] = pos;
  if (!entrada || !saida) { console.error("Uso: node voz.mjs gerar roteiro.txt saida.mp3"); process.exit(1); }
  const voz = opt.voz || get("CORTEX_VOICE_ID");
  if (!voz) { console.error("Escolha uma voz: rode `node voz.mjs vozes` e salve CORTEX_VOICE_ID no .env, ou use --voz=ID"); process.exit(1); }
  const partes = dividir(readFileSync(entrada, "utf8").trim());
  if (partes.length === 1) { await tts(partes[0], voz, saida); console.log("Narração salva em " + saida); process.exit(0); }
  const tmp = mkdtempSync(join(os.tmpdir(), "cortex-voz-"));
  const lista = [];
  for (let i = 0; i < partes.length; i++) {
    const f = join(tmp, `p${i}.mp3`);
    console.log(`Gerando parte ${i + 1} de ${partes.length}…`);
    await tts(partes[i], voz, f, partes[i - 1], partes[i + 1]);
    lista.push(`file '${f.replace(/'/g, "'\\''")}'`);
  }
  writeFileSync(join(tmp, "lista.txt"), lista.join("\n"));
  execFileSync("ffmpeg", ["-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", join(tmp, "lista.txt"), "-c:a", "libmp3lame", "-b:a", "128k", saida], { stdio: "inherit" });
  rmSync(tmp, { recursive: true, force: true });
  console.log(`Narração salva em ${saida} (${partes.length} partes juntadas)`);
  process.exit(0);
}

console.log("Uso: node voz.mjs vozes | node voz.mjs gerar roteiro.txt saida.mp3 [--voz=ID]");
