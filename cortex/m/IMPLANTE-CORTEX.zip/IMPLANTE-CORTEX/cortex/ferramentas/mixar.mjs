#!/usr/bin/env node
// Córtex · mixagem final
// Junta a narração com uma trilha (opcional), abaixando a trilha automaticamente quando a voz fala.
// Uso: node mixar.mjs narracao.mp3 saida.wav [--trilha=musica.mp3] [--volume-trilha=0.22] [--duracao=SEGUNDOS]
import { execFileSync } from "node:child_process";

const args = process.argv.slice(2);
const opt = Object.fromEntries(args.filter((a) => a.startsWith("--")).map((a) => a.slice(2).split("=")));
const [voz, saida] = args.filter((a) => !a.startsWith("--"));
if (!voz || !saida) { console.error("Uso: node mixar.mjs narracao.mp3 saida.wav [--trilha=musica.mp3]"); process.exit(1); }

const dur = opt.duracao ? ["-t", opt.duracao] : [];
let a;
if (opt.trilha) {
  const vol = opt["volume-trilha"] || "0.22";
  a = ["-y", "-i", voz, "-stream_loop", "-1", "-i", opt.trilha, "-filter_complex",
    `[1:a]volume=${vol},afade=t=in:d=1[m];[m][0:a]sidechaincompress=threshold=0.03:ratio=8:attack=20:release=400[duck];[0:a][duck]amix=inputs=2:duration=first:normalize=0,loudnorm=I=-14:TP=-1.5:LRA=11[out]`,
    "-map", "[out]", "-ar", "48000", "-ac", "2", ...dur, saida];
} else {
  a = ["-y", "-i", voz, "-af", "loudnorm=I=-14:TP=-1.5:LRA=11", "-ar", "48000", "-ac", "2", ...dur, saida];
}
execFileSync("ffmpeg", ["-v", "error", ...a], { stdio: "inherit" });
console.log("Áudio final salvo em " + saida);
