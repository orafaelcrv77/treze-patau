# Catálogo de estilos

Cada estilo tem: pra que serve, a receita de montagem (pra IA) e o pedido pronto (pra pessoa copiar e trocar o que está entre colchetes).
A pessoa pode pedir qualquer estilo novo. Estes são o ponto de partida.

---

## 1. Frase de impacto
**Serve pra:** perfis de motivação, marca pessoal, abertura de anúncio.
**Receita:** uma cena de cinema (pessoa de costas, lugar alto, chuva, madrugada) com zoom lento. A frase entra palavra por palavra, em caixa alta, centralizada, com uma palavra destacada na cor de destaque. 8 a 15 segundos. Trilha forte, sem narração ou com narração curta.
**Pedido pronto:**
> Faz um vídeo de frase de impacto com a frase "[SUA FRASE]". Cena: [pessoa de costas no alto de um prédio, à noite, chuva]. Destaca a palavra "[PALAVRA]".

## 2. Plano-sequência
**Serve pra:** explicar um método, um modelo de negócio, um passo a passo.
**Receita:** fundo escuro com grid. Uma câmera única viaja por uma tela infinita, sem corte. Cada ideia da narração é uma "estação" desenhada em motion (cartões, números contando, setas, ícones), e a câmera desliza de uma estação pra próxima no tempo da fala. Pode abrir com uma cena de impacto e "recuar" pro grid.
**Pedido pronto:**
> Faz um vídeo plano-sequência explicando [ASSUNTO] em [3] partes: [PARTE 1], [PARTE 2], [PARTE 3]. Termina pedindo pra comentar [PALAVRA].

## 3. Personagem realista
**Serve pra:** anúncio, depoimento ilustrativo, história de cliente.
**Receita:** crie uma personagem com retrato de referência e 4 a 6 cenas dela no mesmo lugar (veja o módulo de cena). Planos de 1 a 3 segundos, câmera sempre andando, legenda palavra por palavra. Na virada da história, as cenas saem e entra motion em fundo escuro desenhando a solução. Deixe claro pra pessoa que a personagem é fictícia.
**Pedido pronto:**
> Faz um anúncio com uma personagem: [dona de loja de roupa, 35 anos], preocupada com [janeiro fraco]. A virada é [o evento / o produto]. Chamada: [clica no link].

## 4. Personagem ilustrado
**Serve pra:** contar história com humor ou nostalgia, marca com mascote.
**Receita:** personagem desenhado em traço (SVG) com expressão que muda conforme a fala: piscar, apontar, levantar a mão. Cenário mínimo em traço. Elementos da história aparecem desenhados ao lado.
**Pedido pronto:**
> Faz um vídeo com um personagem ilustrado: [um lojista de 70 anos], contando [os erros que ele cometeu em 40 Black Fridays]. Tom [bem-humorado].

## 5. Animação explicativa
**Serve pra:** conteúdo educativo, especialistas, processos.
**Receita:** ícones e linhas em traço que se desenham no ritmo da narração (stroke animado), números que contam, uma linha do tempo que avança. Paleta reduzida, fundo escuro.
**Pedido pronto:**
> Faz uma animação explicando [COMO FUNCIONA X], com ícones desenhados no ritmo da voz.

## 6. Convite animado
**Serve pra:** evento, live, aula, lançamento.
**Receita:** começa pela dor do público, apresenta o evento, mostra data e horário grandes, e termina com um botão animado e um cursor clicando.
**Pedido pronto:**
> Faz um convite animado pro [EVENTO], no dia [DATA] às [HORA]. Começa falando da dor de [PÚBLICO]. Termina com um botão "[TEXTO DO BOTÃO]".

## 7. Sua gravação com motion
**Serve pra:** quem grava. Veja o módulo `05-finalizacao.md`.
**Receita:** título de gancho, legenda palavra por palavra, destaques animados nos números e listas, cortes de pausa aprovados.
**Pedido pronto:**
> Finaliza esse vídeo [ARQUIVO]: corta as pausas, coloca um título de gancho, legenda e destaques.

## 8. Lista rápida
**Serve pra:** dicas, hábitos, erros, "3 coisas que...".
**Receita:** título no topo, itens entrando um por vez com número grande, cada item com um ícone ou cena curta. Transição marcada a cada item.
**Pedido pronto:**
> Faz um vídeo de lista: "[3 hábitos de quem acorda cedo]". Itens: [1], [2], [3].

## 9. Oferta de produto
**Serve pra:** loja, promoção, produto digital.
**Receita:** produto em destaque (foto da pessoa como referência ou cena gerada), preço grande que entra com impacto, condição (prazo, estoque) e chamada pro WhatsApp ou link. Use só preço e condição que a pessoa informou.
**Pedido pronto:**
> Faz um vídeo da oferta: [PRODUTO] por [PREÇO], só até [PRAZO]. Chamada: [chama no WhatsApp]. Foto do produto: [ARQUIVO].

## 10. Pergunta que provoca
**Serve pra:** gerar comentário e alimentar automação de direct.
**Receita:** uma pergunta forte na tela, comentários fictícios aparecendo (deixe claro que são ilustrativos) e a chamada "comenta [PALAVRA]".
**Pedido pronto:**
> Faz um vídeo com a pergunta "[PERGUNTA]" pra gerar comentário. Termina pedindo pra comentar [PALAVRA].

---

## Estilos que a pessoa inventar

Se ela pedir algo fora da lista, monte com a mesma linguagem visual (veja o módulo de montagem) e, se ficar bom, ofereça salvar como estilo novo neste arquivo, com receita e pedido pronto.
