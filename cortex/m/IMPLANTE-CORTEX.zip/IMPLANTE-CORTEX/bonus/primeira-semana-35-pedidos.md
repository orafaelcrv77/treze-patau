# Bônus · Sua primeira semana (35 pedidos)

Um pedido por dia, durante 7 dias, pra cada tipo de uso. Escolha a coluna que é a sua e siga a ordem: ela vai do mais simples ao mais completo, pra você pegar o jeito.

## Se você cria conteúdo
- **Dia 1:** Faz um vídeo de frase de impacto com a frase que resume o meu trabalho: "[FRASE]".
- **Dia 2:** Faz um vídeo respondendo a pergunta que mais me fazem: "[PERGUNTA]".
- **Dia 3:** Faz um vídeo de lista: "3 erros de quem está começando em [NICHO]".
- **Dia 4:** Faz uma animação explicando [CONCEITO] em 30 segundos.
- **Dia 5:** Finaliza essa gravação minha [ARQUIVO] com título, legenda e destaques.
- **Dia 6:** Faz um vídeo plano-sequência com o meu passo a passo de [PROCESSO].
- **Dia 7:** Faz um vídeo convidando pra me seguir e dizendo o que a pessoa vai encontrar aqui.

## Se você anuncia
- **Dia 1:** Faz 3 ganchos diferentes pro anúncio do [PRODUTO].
- **Dia 2:** Faz o anúncio de 20 segundos com o melhor gancho.
- **Dia 3:** Faz uma versão do anúncio respondendo a objeção "[OBJEÇÃO]".
- **Dia 4:** Faz uma versão com personagem vivendo a dor de [DOR].
- **Dia 5:** Faz uma versão estilo animação explicativa.
- **Dia 6:** Faz uma versão de 15 segundos só com benefício e chamada.
- **Dia 7:** Faz uma versão pra quem já visitou o site e não comprou.

## Se você lança
- **Dia 1:** Faz um vídeo revelando o tema do lançamento sem dizer o produto: [TEMA].
- **Dia 2:** Faz o convite animado pra aula [NOME], dia [DATA] às [HORA].
- **Dia 3:** Faz o vídeo "o que você vai aprender": [1], [2], [3].
- **Dia 4:** Faz o vídeo apresentando o especialista: [NOME], [CREDENCIAIS REAIS].
- **Dia 5:** Faz o vídeo de quebra da objeção "não tenho tempo".
- **Dia 6:** Faz o vídeo de abertura de carrinho com o bônus [BÔNUS].
- **Dia 7:** Faz o vídeo de último dia de carrinho.

## Se você tem perfil dark
- **Dia 1:** Faz um vídeo de frase de impacto: "ninguém vai vir te salvar", cena de chuva no alto de um prédio.
- **Dia 2:** Faz um vídeo de lista: "3 hábitos de quem acorda cedo".
- **Dia 3:** Faz um vídeo estoico com uma frase de Marco Aurélio.
- **Dia 4:** Faz um vídeo de história com virada no final, sobre alguém que começou do zero.
- **Dia 5:** Faz um vídeo pergunta que provoca: "comenta SIM se você vai começar hoje".
- **Dia 6:** Faz um vídeo de motivação pra segunda-feira, cena de estrada ao amanhecer.
- **Dia 7:** Faz um vídeo chamando pro ebook do perfil: "[NOME DO EBOOK]", link na bio.

## Se você tem loja ou negócio local
- **Dia 1:** Faz o vídeo da oferta da semana: [PRODUTO] por [PREÇO]. Foto: [ARQUIVO].
- **Dia 2:** Faz o vídeo das novidades chegando: [PRODUTOS]. Fotos: [ARQUIVOS].
- **Dia 3:** Faz o vídeo "3 jeitos de usar [PRODUTO]".
- **Dia 4:** Faz o vídeo convidando pra visitar a loja em [ENDEREÇO].
- **Dia 5:** Faz o vídeo do produto mais vendido do mês: [PRODUTO].
- **Dia 6:** Faz o vídeo de entrega: "a gente entrega em [BAIRROS]".
- **Dia 7:** Faz o vídeo agradecendo os clientes da semana, com cena da loja.
