# CÓRTEX · comece por aqui

Bem-vindo. Em poucos minutos a sua IA vai saber fazer vídeo.

## Você vai precisar de

- Um computador, **Mac ou Windows**, com internet.
- Uma IA no plano pago com o modo de programação:
  - **Claude**, usando o **Claude Code** (claude.ai → app do Claude no computador, aba Code), ou
  - **ChatGPT**, usando o **Codex**.
- Uns 15 minutos na primeira vez.

## Instalação em 3 passos

**1.** Abra o Claude Code ou o Codex numa pasta qualquer do seu computador (pode ser a pasta Documentos).

**2.** Arraste a pasta **IMPLANTE-CORTEX** (descompactada) pra dentro da conversa, ou diga onde ela está, e cole esta frase:

```
Instale o Córtex seguindo o arquivo INSTALAR.md que está nesta pasta.
```

**3.** A IA vai instalar tudo e te pedir a chave do **ElevenLabs** (a voz, tem plano grátis pra começar). Ela explica o passo a passo. É só copiar e colar na conversa. Ela também vai perguntar se você quer a geração automática de imagens do Google, que é opcional.

Quando aparecer **"Córtex instalado"**, está pronto.

## Como usar

Escreva o que você quer, do jeito que pediria pra um editor:

> Faz um vídeo de lista: "3 erros de quem está começando no Instagram", pra comentar a palavra DICA no final.

A IA vai:
1. te mostrar o roteiro pra aprovar;
2. criar as cenas e a narração;
3. pedir pra você escutar a voz;
4. montar e te entregar o vídeo pronto, na pasta **Cortex/videos**.

Pediu ajuste? É só falar: "troca o gancho", "deixa mais curto", "muda a voz".

## Onde estão as suas coisas

| Pasta | O que tem |
|---|---|
| `Cortex/pedidos` | Os 130 pedidos prontos, por uso |
| `Cortex/bonus` | O guia Perfil Dark do zero e os 35 pedidos da primeira semana |
| `Cortex/videos` | Todos os vídeos que você fizer |

## Custos que ficam com você

O Córtex você já pagou, uma vez. Fora ele, você usa:
- a assinatura da sua IA (Claude ou ChatGPT, a partir de US$ 20 por mês);
- o ElevenLabs (a voz), que tem plano grátis pra começar. Se você fizer muitos vídeos, ele pode pedir um plano pago;
- as imagens: de graça pelo app do Gemini (você gera e salva, a IA te guia), ou automático pela chave do Google com faturamento ativo, que cobra alguns centavos por imagem.

Esses valores ficam na conta de cada serviço, não passam pela gente. E vários estilos (animação, lista, convite, plano-sequência, finalização) nem usam imagem.

## Precisa de ajuda?

Fale com a sua IA primeiro: ela consegue resolver a maior parte dos problemas sozinha. Se travar, chame no WhatsApp **(61) 99874-1443**.

Garantia de 7 dias: se não instalar ou se você não gostar, pede o reembolso pela plataforma de compra.
