# PACK ANÚNCIOS · complemento do Córtex

Este pack ensina a sua IA a criar anúncios em lote pra testar, do jeito que gestor de tráfego trabalha: poucos ângulos, vários ganchos, arquivos organizados pra você descobrir rápido qual funciona.

Precisa do Córtex instalado antes.

## O que vem

| Arquivo | O que é |
|---|---|
| `modulo/06-anuncios.md` | O módulo novo que a sua IA aprende: briefing, ângulos, matriz de teste, estrutura de 15 e 30 segundos, formatos, checklist e leitura dos resultados |
| `pedidos/100-pedidos-de-anuncio.md` | 100 pedidos prontos separados por nicho: infoproduto, loja, serviço local, beleza e saúde, comida, imóveis, profissional liberal |
| `pedidos/banco-de-ganchos.md` | 60 modelos de gancho pros 3 primeiros segundos, por ângulo |

## Instalação (1 minuto)

Abra o Claude Code ou o Codex, arraste esta pasta pra conversa e cole:

```
Instale o Pack Anúncios: copie modulo/06-anuncios.md pra pasta modulos do Córtex instalado, acrescente na tabela "Onde está cada coisa" do SKILL.md do Córtex a linha "| modulos/06-anuncios.md | Anúncios em lote pra testar: leia antes do roteiro sempre que o pedido for anúncio |", e copie a pasta pedidos deste pack pra Cortex/pedidos/anuncios.
```

Pronto. A partir daí, todo pedido de anúncio passa pelo módulo novo.

## Como usar

> Faz 9 variações de anúncio pra minha loja de roupa no Sudoeste, que vende moda feminina de R$ 80 a R$ 200, com chamada pro WhatsApp.

A IA vai te fazer até 5 perguntas, montar a matriz (3 ângulos × 3 ganchos), mostrar pra você aprovar e só então gerar os vídeos, já com nome de arquivo dizendo o que cada um testa.

## Importante

O pack te ajuda a produzir e organizar os testes. O resultado do anúncio depende também da oferta, do público, do orçamento e da página. Nenhum criativo garante venda, e a IA não vai prometer isso no seu lugar.

Dúvidas: WhatsApp **(61) 99874-1443**.
