# Módulo 06 · Anúncios (Pack Anúncios)

Use este módulo sempre que a pessoa pedir anúncio, criativo, vídeo pra tráfego pago ou "vários criativos pra testar". Ele vem antes do `01-roteiro.md`: primeiro você decide o que testar, depois escreve cada roteiro.

## A ideia central

Anúncio bom é descoberto, não adivinhado. Ninguém acerta o criativo vencedor de primeira, nem agência grande. Por isso o seu trabalho não é fazer "o anúncio perfeito". É entregar um lote pequeno de variações bem diferentes entre si, organizado pra pessoa descobrir rápido qual funciona.

## Passo 1 · Briefing (no máximo 5 perguntas)

Pergunte só o que faltar:
1. O que está sendo vendido e por quanto.
2. Pra quem (quem compra, não "todo mundo").
3. O que a pessoa quer que o público faça: comprar no site, chamar no WhatsApp, se cadastrar, visitar a loja.
4. A objeção que ela mais escuta ("tá caro", "não tenho tempo", "será que funciona pra mim").
5. Se tem prova real: depoimento autorizado, print, número de clientes, tempo de mercado. Se não tiver, não invente. Anúncio sem prova usa demonstração.

## Passo 2 · Escolher 3 ângulos

Ângulo é a porta de entrada do anúncio. Escolha 3 bem diferentes desta lista:

| Ângulo | A conversa começa por | Exemplo de abertura |
|---|---|---|
| Dor | o problema que incomoda hoje | "Você posta todo dia e ninguém comenta." |
| Desejo | a vida depois de resolvido | "Imagina abrir o WhatsApp e ter pedido esperando." |
| Objeção | a dúvida que trava a compra | "Achou caro? Faz essa conta comigo." |
| Prova | algo real que já aconteceu | "Essa cliente mandou esse áudio ontem." |
| Comparação | o jeito antigo contra o novo | "Editor cobra R$ 200 por vídeo. Olha a alternativa." |
| Curiosidade | uma informação que falta | "Tem um detalhe na sua vitrine que espanta cliente." |
| Erro comum | o que a maioria faz errado | "O erro que faz seu anúncio ser ignorado em 1 segundo." |
| Bastidor | como é feito por dentro | "Olha como esse bolo sai da cozinha até sua mesa." |
| Oferta | condição concreta e com prazo real | "Até domingo, a segunda peça sai pela metade." |

Explique em uma linha pra pessoa por que escolheu cada ângulo.

## Passo 3 · A matriz de teste

Pra cada ângulo, escreva 3 ganchos diferentes (os 3 primeiros segundos). O corpo do anúncio pode ser o mesmo dentro do ângulo. Resultado: 9 variações com só 3 roteiros de corpo.

```
            gancho A   gancho B   gancho C
ângulo 1       1A         1B         1C
ângulo 2       2A         2B         2C
ângulo 3       3A         3B         3C
```

Mostre a matriz como tabela pra pessoa aprovar antes de gerar qualquer coisa. Se ela quiser economizar crédito, comece só pela linha do ângulo que ela mais acredita.

Use o `banco-de-ganchos.md` do pack como ponto de partida, sempre adaptado ao negócio dela. Gancho genérico não para ninguém.

## Passo 4 · Estrutura do anúncio

**15 segundos (público que já conhece):**
1. 0 a 3 s · gancho (tela e voz juntos)
2. 3 a 11 s · o benefício principal mostrado, não descrito
3. 11 a 15 s · chamada com a ação exata ("toca em Saiba mais", "chama no WhatsApp")

**30 segundos (público frio):**
1. 0 a 3 s · gancho
2. 3 a 10 s · o problema com um detalhe que a pessoa reconhece
3. 10 a 22 s · a solução e como funciona, em até 3 passos
4. 22 a 26 s · prova ou quebra da objeção
5. 26 a 30 s · chamada

Regras:
- A chamada aparece escrita na tela e falada. Uma ação só.
- O nome do produto ou da marca aparece pelo menos uma vez.
- Legenda sempre ligada: muita gente vê sem som.
- Preço só se a pessoa informou e quiser mostrar.

## Passo 5 · Formatos

Renderize o principal em 9:16 (1080x1920), que serve pra Reels, Stories e TikTok. Se a pessoa for anunciar também no feed, faça uma versão 4:5 (1080x1350) recompondo os elementos, não só cortando. Nos dois, respeite as áreas livres do `SKILL.md`.

## Passo 6 · Nome dos arquivos

Salve cada variação com um nome que diga o que ela testa:

```
videos/2026-10-10-anuncio-loja/
  1A-dor-vitrine-vazia-9x16.mp4
  1B-dor-cliente-so-olha-9x16.mp4
  2A-oferta-segunda-peca-9x16.mp4
```

Assim, quando a pessoa olhar o resultado no gerenciador de anúncios, ela sabe na hora qual ângulo e qual gancho ganharam.

## Passo 7 · Checklist antes de entregar

- [ ] O gancho aparece em até 3 segundos, na tela e na voz.
- [ ] Os 3 ângulos são realmente diferentes (não é o mesmo texto com outra palavra).
- [ ] Nenhuma frase de risco de `regras/anuncios.md` sem aviso.
- [ ] Nenhum número, depoimento ou resultado inventado.
- [ ] Chamada com uma ação só.
- [ ] Legenda ligada e fora das áreas dos botões.
- [ ] Arquivos com nome de teste.

## Passo 8 · Depois que rodar

Quando a pessoa voltar com os números, ajude a ler sem inventar referência de mercado:
- Compare as variações entre si, nunca com "média do mercado".
- Gancho que segura mais gente nos primeiros segundos ganhou o teste de gancho. Corpo que leva mais gente a clicar ganhou o teste de ângulo.
- O vencedor vira base: mantenha o ângulo e faça 3 ganchos novos pra ele. Os perdedores saem.
- Se nenhum funcionou, o problema costuma estar antes do criativo: oferta, público ou página. Diga isso com cuidado.

Peça os números do jeito que a pessoa conseguir mandar (print do gerenciador serve) e responda em linguagem simples.
