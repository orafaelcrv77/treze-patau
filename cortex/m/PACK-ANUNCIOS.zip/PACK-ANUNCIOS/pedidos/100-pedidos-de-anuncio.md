# 100 pedidos de anúncio, por nicho

Copie, troque o que está entre colchetes e mande pra sua IA. Ela segue o módulo de anúncios: monta a matriz de teste, mostra pra você aprovar e só depois gera.

Dica: quanto mais detalhe real você colocar no lugar dos colchetes (nome do produto, bairro, preço, a frase que o cliente fala), melhor o anúncio.

## Infoproduto e expert (20)

1. Faz 9 variações de anúncio pro meu curso [NOME], que custa [PREÇO], pra [PÚBLICO]. Ângulos: dor, objeção e comparação.
2. Faz um anúncio de 30 segundos pro meu ebook [NOME] começando pelo erro mais comum de quem [SITUAÇÃO].
3. Faz um anúncio pra minha mentoria mostrando como é uma semana de quem participa, sem prometer resultado.
4. Faz 3 ganchos diferentes pro anúncio do [PRODUTO] usando a objeção "[OBJEÇÃO]".
5. Faz um anúncio de captação pra minha aula gratuita sobre [TEMA], com chamada pra se inscrever.
6. Faz um anúncio de 15 segundos pra quem visitou minha página de vendas e não comprou o [PRODUTO].
7. Faz um anúncio mostrando o que tem dentro do [PRODUTO], módulo por módulo, em estilo lista rápida.
8. Faz um anúncio usando o print de depoimento real que vou te mandar: [ARQUIVO].
9. Faz um anúncio comparando quanto custa aprender [TEMA] sozinho (tempo e erro) com o [PRODUTO].
10. Faz um anúncio de perguntas e respostas: as 3 dúvidas que mais recebo sobre o [PRODUTO].
11. Faz um anúncio com a minha gravação [ARQUIVO], cortando as pausas e colocando título e legenda.
12. Faz um anúncio estilo frase de impacto pro meu perfil, chamando pra seguir e comentar [PALAVRA].
13. Faz um anúncio de abertura de carrinho: [PRODUTO] abre dia [DATA], com chamada pra lista de espera.
14. Faz um anúncio de último dia de inscrição do [PRODUTO], com o prazo real [DATA E HORA].
15. Faz um anúncio explicando pra quem o [PRODUTO] não serve, pra filtrar curioso.
16. Faz um anúncio de bastidor: como eu preparo o conteúdo do [PRODUTO].
17. Faz um anúncio com a garantia de [DIAS] dias como argumento principal.
18. Faz um anúncio animado explicando o método [NOME DO MÉTODO] em 3 passos.
19. Faz um anúncio pro meu desafio de [DIAS] dias sobre [TEMA], com chamada pra entrar no grupo.
20. Faz um anúncio de público frio sobre [TEMA] que só fala do [PRODUTO] nos últimos 5 segundos.

## Loja física e e-commerce (20)

21. Faz 9 variações de anúncio pra minha loja [NOME], que vende [PRODUTOS] em [CIDADE].
22. Faz um anúncio do produto [PRODUTO] mostrando 3 jeitos de usar.
23. Faz um anúncio de oferta: [PRODUTO] de [PREÇO ANTIGO] por [PREÇO NOVO] até [DATA].
24. Faz um anúncio com as fotos do produto que vou te mandar, com movimento e preço na tela.
25. Faz um anúncio de "chegou novidade" com os lançamentos da semana: [LISTA].
26. Faz um anúncio de frete grátis acima de [VALOR] pra [REGIÃO].
27. Faz um anúncio de recuperação de carrinho com o produto [PRODUTO] e o cupom [CUPOM].
28. Faz um anúncio de kit presente pro [DATA COMEMORATIVA], com os itens [LISTA] e preço [PREÇO].
29. Faz um anúncio comparando o [PRODUTO] com a versão barata que estraga rápido, sem citar marca de ninguém.
30. Faz um anúncio de bastidor: como embalamos os pedidos.
31. Faz um anúncio com a gravação do provador [ARQUIVO], com legenda e preço de cada look.
32. Faz um anúncio de liquidação de estoque com [PERCENTUAL] de desconto nas peças [CATEGORIA].
33. Faz um anúncio respondendo "será que serve em mim?" pro produto [PRODUTO], com a tabela de medidas.
34. Faz um anúncio de "compre junto": [PRODUTO A] + [PRODUTO B] por [PREÇO].
35. Faz um anúncio de visita à loja: endereço [ENDEREÇO], horário [HORÁRIO], com mapa animado.
36. Faz um anúncio pra Black Friday com as ofertas [LISTA], válidas de [DATA] a [DATA].
37. Faz um anúncio de pergunta que provoca: "[PERGUNTA SOBRE O PROBLEMA QUE O PRODUTO RESOLVE]".
38. Faz um anúncio com o detalhe que ninguém repara no [PRODUTO] (acabamento, material, costura).
39. Faz um anúncio de troca fácil: explica a política de troca de [DIAS] dias em 15 segundos.
40. Faz um anúncio de produto mais vendido da loja: [PRODUTO], com o motivo real de vender tanto.

## Serviço local (15)

41. Faz 9 variações de anúncio pro meu [SERVIÇO] em [BAIRRO / CIDADE], com chamada pro WhatsApp.
42. Faz um anúncio mostrando o antes e depois do serviço [SERVIÇO] num [AMBIENTE], com as fotos reais que vou mandar.
43. Faz um anúncio de agenda aberta: horários livres essa semana pra [SERVIÇO].
44. Faz um anúncio explicando como funciona o orçamento: [PASSOS].
45. Faz um anúncio com o erro mais comum de quem contrata [SERVIÇO] e como evitar.
46. Faz um anúncio de atendimento em [BAIRROS], com mapa animado da região.
47. Faz um anúncio respondendo "quanto custa [SERVIÇO]?", com a faixa de preço [FAIXA] e o que muda o valor.
48. Faz um anúncio com a minha gravação no trabalho [ARQUIVO], com título e legenda.
49. Faz um anúncio de emergência: [SERVIÇO] 24 horas em [CIDADE], com o número na tela.
50. Faz um anúncio de pacote mensal de [SERVIÇO] por [PREÇO].
51. Faz um anúncio de primeira visita com [CONDIÇÃO] pra quem chamar até [DATA].
52. Faz um anúncio mostrando as ferramentas e o cuidado no [SERVIÇO], em estilo bastidor.
53. Faz um anúncio com o áudio de cliente que vou te mandar: [ARQUIVO], com legenda.
54. Faz um anúncio de "3 sinais de que você precisa de [SERVIÇO]".
55. Faz um anúncio pra empresa: [SERVIÇO] pra escritórios e lojas em [CIDADE].

## Beleza, estética e saúde (15)

Atenção: essas áreas têm regras mais duras nas plataformas. A IA vai avisar das frases de risco.

56. Faz 9 variações de anúncio pro meu [PROCEDIMENTO] no [NOME DO ESPAÇO], sem prometer resultado.
57. Faz um anúncio explicando como é o [PROCEDIMENTO] passo a passo, do agendamento ao fim.
58. Faz um anúncio respondendo "dói?" sobre o [PROCEDIMENTO], com a resposta honesta.
59. Faz um anúncio de horário livre na agenda de [DIA], com chamada pro WhatsApp.
60. Faz um anúncio mostrando o ambiente do meu espaço com as fotos que vou mandar.
61. Faz um anúncio de cuidado pós [PROCEDIMENTO]: 3 coisas que ninguém te conta.
62. Faz um anúncio de pacote de [SESSÕES] sessões por [PREÇO].
63. Faz um anúncio da minha formação e experiência: [FORMAÇÃO], [ANOS] anos de atendimento.
64. Faz um anúncio para o [DIA DAS MÃES / NAMORADOS] com vale-presente de [SERVIÇO].
65. Faz um anúncio de pergunta: "[PERGUNTA QUE O CLIENTE SEMPRE FAZ]", com a resposta curta.
66. Faz um anúncio da minha clínica com chamada pra avaliação, sem citar condição de saúde de quem assiste.
67. Faz um anúncio de produto de beleza [PRODUTO], mostrando a textura e o modo de usar.
68. Faz um anúncio com a minha gravação explicando [TEMA], finalizada com legenda e destaques.
69. Faz um anúncio de academia / studio: aula experimental grátis em [DIA], em [ENDEREÇO].
70. Faz um anúncio de nutrição: 3 trocas simples no [REFEIÇÃO], sem promessa de perda de peso.

## Comida e delivery (10)

71. Faz 9 variações de anúncio pro meu [RESTAURANTE / DELIVERY] em [BAIRRO].
72. Faz um anúncio do prato [PRATO] com as fotos que vou mandar, com preço e chamada pro pedido.
73. Faz um anúncio de bastidor: o [PRATO] sendo montado do começo ao fim.
74. Faz um anúncio de cardápio da semana: [LISTA COM PREÇOS].
75. Faz um anúncio de combo: [ITENS] por [PREÇO], só de [DIA] a [DIA].
76. Faz um anúncio de encomenda: [PRODUTO] pra [DATA COMEMORATIVA], pedidos até [DATA].
77. Faz um anúncio de horário: abrimos [HORÁRIO] em [ENDEREÇO], com mapa.
78. Faz um anúncio pra marmita congelada: [OPÇÕES], [PREÇO], entrega em [REGIÃO].
79. Faz um anúncio de bolo / doce sob encomenda com os sabores [LISTA].
80. Faz um anúncio de pergunta: "já pediu [PRATO] hoje?", em estilo frase de impacto.

## Imóveis (10)

Atenção: imóveis tem regras próprias de anúncio em várias plataformas. A IA vai avisar.

81. Faz um anúncio do imóvel [TIPO] em [BAIRRO], com as fotos que vou mandar e os dados [QUARTOS, ÁREA, VALOR].
82. Faz um anúncio de lançamento: [EMPREENDIMENTO], com prédio animado e as plantas [DADOS].
83. Faz um anúncio de "3 coisas pra olhar antes de alugar um apartamento".
84. Faz um anúncio de tour pelo imóvel com a minha gravação [ARQUIVO].
85. Faz um anúncio de captação: "quer vender seu imóvel em [BAIRRO]? Avaliação sem custo".
86. Faz um anúncio comparando aluguel e financiamento com os números que eu informar: [NÚMEROS].
87. Faz um anúncio de visita: plantão no [ENDEREÇO] dia [DATA].
88. Faz um anúncio sobre o bairro [BAIRRO]: o que tem perto, em estilo lista.
89. Faz um anúncio com a minha apresentação como corretor: [CRECI], [REGIÃO DE ATUAÇÃO].
90. Faz um anúncio de imóvel pra investidor, sem prometer rentabilidade.

## Profissional liberal (10)

Advogado, contador, dentista, psicólogo, arquiteto. Cada conselho tem regra própria de publicidade. Confira a do seu antes de subir.

91. Faz um anúncio informativo sobre [DIREITO / OBRIGAÇÃO] que muita gente não sabe, com chamada pra conversar.
92. Faz um anúncio de prazo: "[OBRIGAÇÃO] vence dia [DATA]", pra contador.
93. Faz um anúncio explicando como funciona a primeira consulta no meu escritório.
94. Faz um anúncio de pergunta: "[DÚVIDA COMUM DO CLIENTE]?", com a resposta em 20 segundos.
95. Faz um anúncio com a minha gravação [ARQUIVO], finalizada com título e legenda.
96. Faz um anúncio de "3 erros que [PÚBLICO] comete com [TEMA]".
97. Faz um anúncio do meu consultório: ambiente, localização e horário, com as fotos que vou mandar.
98. Faz um anúncio de projeto de arquitetura: antes e depois com as imagens [ARQUIVOS].
99. Faz um anúncio pra empresas: [SERVIÇO] pra [TIPO DE EMPRESA] em [CIDADE].
100. Faz um anúncio animado explicando [PROCESSO] em 3 passos, sem juridiquês.
