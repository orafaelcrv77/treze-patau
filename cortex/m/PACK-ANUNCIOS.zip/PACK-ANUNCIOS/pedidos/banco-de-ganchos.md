# Banco de ganchos

60 modelos de abertura pros 3 primeiros segundos, separados por ângulo. Troque os colchetes pelo detalhe do seu negócio. Gancho genérico não para ninguém: quanto mais específico, melhor.

Pra usar: "Usa os ganchos 4, 12 e 31 do banco de ganchos no anúncio do [PRODUTO]."

## Dor (1 a 10)
1. "Você [AÇÃO DO DIA A DIA] e mesmo assim [RESULTADO RUIM]."
2. "Se o seu [COISA] está [PROBLEMA], o motivo provavelmente é esse."
3. "Cansou de [SITUAÇÃO REPETIDA]?"
4. "Toda [DIA DA SEMANA] é a mesma coisa: [PROBLEMA]."
5. "O [PROBLEMA] não começa onde você acha."
6. "Tem [PÚBLICO] perdendo [COISA] todo mês sem perceber."
7. "Isso aqui acontece com quase todo [PÚBLICO] que eu atendo."
8. "Você já [SITUAÇÃO CONSTRANGEDORA]? Então assiste até o fim."
9. "O problema não é você. É o [CAUSA REAL]."
10. "Ninguém te avisou que [VERDADE INCÔMODA]."

## Desejo (11 a 18)
11. "Imagina [CENA DO RESULTADO] numa [DIA COMUM]."
12. "Como seria se [PROBLEMA] simplesmente parasse?"
13. "Isso aqui é o que muda quando [RESULTADO]."
14. "O dia em que eu [CONQUISTA], foi assim."
15. "Quer [RESULTADO] sem [SACRIFÍCIO QUE ELA TEME]?"
16. "Olha o que dá pra fazer em [TEMPO CURTO] com [PRODUTO]."
17. "[RESULTADO] também é pra quem [LIMITAÇÃO]."
18. "Esse é o [OBJETO] que todo [PÚBLICO] queria ter."

## Objeção (19 a 27)
19. "Achou caro? Faz essa conta comigo."
20. "'Não tenho tempo.' Então você precisa ver isso."
21. "Será que funciona pra quem [SITUAÇÃO]? Funciona, e eu te mostro."
22. "Você não precisa [EXIGÊNCIA QUE ASSUSTA] pra [RESULTADO]."
23. "A pergunta que mais recebo: [PERGUNTA]."
24. "Se você já tentou [ALTERNATIVA] e não deu certo, isso é diferente por um motivo."
25. "Não sabe por onde começar? Começa por aqui."
26. "E se não gostar? [CONDIÇÃO DA GARANTIA]."
27. "Parece difícil. Não é. Olha."

## Prova (28 a 34)
Use só com prova real e autorizada.
28. "Essa mensagem chegou ontem." (mostra o print)
29. "Escuta o que a [NOME AUTORIZADO] falou." (áudio real)
30. "[NÚMERO REAL] [CLIENTES / PEDIDOS / ANOS]. Isso é o que aprendi."
31. "Esse foi o resultado da [CLIENTE] em [PRAZO REAL]."
32. "Eu fiz isso aqui em [TEMPO REAL]. Ao vivo."
33. "Olha a fila na porta hoje." (gravação real)
34. "Antes / depois, sem filtro." (só onde a plataforma permite)

## Comparação (35 a 41)
35. "[ALTERNATIVA CARA] custa [VALOR]. Olha a outra opção."
36. "Do jeito antigo: [TEMPO]. Do jeito novo: [TEMPO]."
37. "Esquerda: [JEITO COMUM]. Direita: [SEU JEITO]."
38. "A diferença entre quem [RESULTADO BOM] e quem [RESULTADO RUIM] é uma só."
39. "Você pode [OPÇÃO DIFÍCIL] ou [OPÇÃO SIMPLES]."
40. "Todo mundo faz [JEITO COMUM]. Por isso ninguém [RESULTADO]."
41. "Mesmo [PRODUTO], dois preços. Te explico."

## Curiosidade (42 a 49)
42. "Tem um detalhe no seu [COISA] que [EFEITO]."
43. "Ninguém fala disso sobre [TEMA]."
44. "Descobri por que [FENÔMENO COMUM]."
45. "O segredo do [COISA FAMOSA] é mais simples do que parece."
46. "Isso aqui parece [COISA A]. Mas é [COISA B]."
47. "Para tudo e olha esse [OBJETO]."
48. "Você sabe o que acontece quando [AÇÃO]?"
49. "Por que todo [PROFISSIONAL] faz [AÇÃO]? Eu te conto."

## Erro comum (50 a 55)
50. "O erro que faz [PÚBLICO] perder [COISA]."
51. "Pare de [AÇÃO COMUM] agora."
52. "3 erros que [PÚBLICO] comete com [TEMA]. O segundo é o pior."
53. "Se você faz isso no seu [COISA], está jogando [RECURSO] fora."
54. "Ninguém te ensinou isso e por isso [PROBLEMA]."
55. "O conselho mais repetido sobre [TEMA] está errado."

## Oferta e urgência real (56 a 60)
Use só com prazo e condição verdadeiros.
56. "Até [DIA REAL], [CONDIÇÃO]."
57. "Últimas [QUANTIDADE REAL] unidades do [PRODUTO]."
58. "[PRODUTO] por [PREÇO]. Só essa semana."
59. "Abriu a agenda de [MÊS]. São [NÚMERO REAL] horários."
60. "Hoje é o último dia. Depois volta pra [PREÇO NORMAL]."
